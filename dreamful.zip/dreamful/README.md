# dreamful
dreamful ios app

## Dependencies

    npm install -g roots
    npm install -g phonegap
    npm install

## Compiling

    roots compile

## Running

### Server

    phonegap serve

### iOS

    phonegap run ios
